# V100 / SM70 数值仿真与结构反推实验包

完整中文报告：[simulation/README.zh-CN.md](simulation/README.zh-CN.md)。

本次实际完成 V100 数值模型执行、公开硬件样本重验、原版 Octave 交叉验证、结构约束搜索、SM70 编译与 Accel-Sim 周期仿真。没有在用户 V100 上进行新的执行或训练测速。

## 快速复跑

需要 Python 3 和 NumPy；数值模型的最小原版快照与硬件 fixture 已包含，无需联网或 Git。以下命令在实验包根目录执行：

```bash
python3 simulation/numerics/run_numerical_study.py --random-cases 4096
python3 simulation/search/structural_search.py
python3 simulation/cost/validate_magic_decode.py
python3 simulation/cost/analyze_cost.py
```

原版模型交叉验证需要 GNU Octave：

```bash
OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 octave-cli --quiet --no-gui simulation/numerics/run_original_octave.m
```

兼容 Linux x86-64 系统可用随包 Accel-Sim 二进制复跑周期模型：

```bash
bash simulation/architecture/run_existing_binary.sh
```

复跑会更新同目录结果和日志；若需要保留原始回执，请从另一份解压副本运行。CPU 数值模型和周期模型互相独立。

## 目录

- `simulation/numerics/`：5,000 个公开硬件样本、模型移植、未改动原版模型快照、885 个原版交叉样例、30,940 次 packing 结果及来源哈希。
- `simulation/search/`：21,504 组线性 radix 充分条件筛选。
- `simulation/cost/`：实际 CUDA 编译产物、9 个候选的 SASS 统计、K4 指令探针、位模式解包及穷举结果。
- `simulation/architecture/`：实际构建的 Accel-Sim、公开 LUD trace、人工 HMMA trace、配置、日志和复跑脚本。
- `gpu_probe/`：上一轮待真实 V100 执行的完整硬件探针；它不代表本次已经实测。新 K4 程序仍是编译探针，位于 cost。
- `compile-evidence/`：上一轮私有 CUDA SDK 的 glibc 兼容补丁及编译依据。

未包含完整 CUDA/Octave 工具链。CUDA 重编译需要 CUDA 12.x；具体私有工具链布局和完整安装的手工命令见 cost 报告。模型、数据和模拟器的原始许可证与固定提交均随包保留。

`SHA256SUMS` 可校验全部交付文件。
